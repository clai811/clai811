const heartsContainer = document.getElementById('hearts');
const colors = ['#ff4081', '#f48fb1', '#ff80ab', '#ff1744', '#ff4081'];

function createHeart(x, y) {
  const heart = document.createElement('div');
  heart.classList.add('heart');
  heart.style.left = x + 'px';
  heart.style.top = y + 'px';
  heart.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
  heartsContainer.appendChild(heart);
  setTimeout(() => heart.remove(), 2000);
}

window.addEventListener('mousemove', e => {
  createHeart(e.clientX - 10, e.clientY - 10);
});

const btnNo = document.getElementById('btn-no');
const btnYes = document.getElementById('btn-yes');

function randomPosition() {
  const padding = 20;
  const maxX = window.innerWidth - btnNo.offsetWidth - padding;
  const maxY = window.innerHeight - btnNo.offsetHeight - padding;
  return {
    x: Math.floor(Math.random() * (maxX - padding)) + padding,
    y: Math.floor(Math.random() * (maxY - padding)) + padding
  };
}

btnNo.addEventListener('mouseenter', () => {
  btnNo.style.opacity = '0';
  const {x, y} = randomPosition();
  btnNo.style.left = x + 'px';
  btnNo.style.top = y + 'px';
  setTimeout(() => btnNo.style.opacity = '1', 300);
});

btnNo.addEventListener('click', () => {
  alert('Adek ganteng banget, jangan pilih yang tidak ya hehe!');
});

btnYes.addEventListener('click', () => {
  window.location.href = "page2.html";
});

btnNo.addEventListener('focus', () => {
  const {x, y} = randomPosition();
  btnNo.style.left = x + 'px';
  btnNo.style.top = y + 'px';
});
